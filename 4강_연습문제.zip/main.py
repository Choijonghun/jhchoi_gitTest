from Question import Q1
from Question import Q2
from Question import Q3
from Question import Q4
from Question import Q5
from Question import Q6
from Question import Q7

Q2()