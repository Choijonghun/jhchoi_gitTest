from Question_5 import q_q1
from Question_5 import q_q2
from Question_5 import q_q3
from Question_5 import q_q4
from Question_5 import q_q5
from Question_5 import q_q6
from Question_5 import q_q7
from Question_5 import q_q8
from Question_5 import q_q9
from Question_5 import q_q10
from Question_5 import q_q11
from Question_5 import q_q12
from Question_5 import q_q13
q_q13()
